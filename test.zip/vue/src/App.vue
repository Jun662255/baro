<template>

<div class="whole">

<div class="login">
  <a href="/login" style="text-decoration-line:none; color:black;">로그인</a> &nbsp;&nbsp;
  <a href="/enroll" style="text-decoration-line:none; color:black;" >회원가입</a>
</div>
<a href="/" style="text-decoration-line:none; color:white;">
<h1>Milky Way</h1>
</a>
  <router-view></router-view>
</div>

</template>

<script>



export default {
  name: 'App',
  components: {

  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  
}
.whole{
  background-color: paleturquoise;
  border:1px solid paleturquoise;
}


</style>

