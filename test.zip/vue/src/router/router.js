import { createWebHistory, createRouter } from "vue-router";
import Home from './components/Home.vue';
import Login from './components/Login.vue';
import Enroll from './components/Enroll.vue';

const routes = [
{
    path: "/",
    component: Home,
},
{
    path: "/login",
    component: Login,
},
{
    path: "/enroll",
    component: Enroll,
}
    
];

const router = createRouter({
history: createWebHistory(),
routes,
});

export default router;    