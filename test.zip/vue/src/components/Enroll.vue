<template>
 
  <h1>여기는 회원가입페이지</h1>
  
    <div class="col" style="margin-left:25%; margin-right:25%;" >
    
     <div class="p-3 border bg-light">
      <br>
        <div class="mb-3 row">
          <label for="inputId" class="col-sm-2 col-form-label">ID</label>
          <div class="col-sm-10">
            <input type="text" class="form-control" id="inputId">
          </div>
        </div>

        <br>
        
        <div class="mb-3 row">
          <label for="inputPassword" class="col-sm-2 col-form-label">Password</label>
          <div class="col-sm-10"  >
            <input type="password" class="form-control" id="inputPassword">
          </div>

        </div>


        <br>

        <div class="mb-3 row" >
          <label for="inputPasswordCheck" class="col-sm-2 col-form-label">PasswordCheck</label>
          <div class="col-sm-10"  >
            <input type="password" class="form-control" id="inputPasswordCheck" placeholder="비밀번호를 다시 입력해주세요.">
          </div>

        </div>

        <br>

        <div class="mb-3 row" >
          <label for="inputName" class="col-sm-2 col-form-label">Name</label>
          <div class="col-sm-10"  >
            <input type="text" class="form-control" id="inputName">
          </div>

        </div>

        <br>

        <div class="mb-3 row" >
          <label for="inputAddress" class="col-sm-2 col-form-label">Address</label>
          <div class="col-sm-10"  >
            <input type="text" class="form-control" id="inputAddress">
          </div>

        </div>

        <br>


          <div class="mb-3 row" >
          <label for="inputPhone" class="col-sm-2 col-form-label">Phone</label>
          <div class="col-sm-10"  >
            <input type="tel" class="form-control" id="inputPhone">
          </div>

        </div>

        <br>

        <div class="mb-3 row" >
          <label for="inputEmail" class="col-sm-2 col-form-label">Email</label>
          <div class="col-sm-10"  >
            <input type="email" class="form-control" id="inputEmail">
          </div>

        </div>
        
        <br>

  <!--로그인 버튼-->
   <div style="text-align:center">
     <button type="submit" class="btn btn-primary" style="width:90px;">회원가입</button>&nbsp;

  <button type="submit" class="btn btn-danger" style="width:90px;">
    <router-link to ="/" style="text-decoration-line:none; color:white">이전으로</router-link>
  </button>
  
     </div>



     </div>

    </div>
    
  
<br><br><br><br><br><br><br><br><br><br>



</template>

<script>
export default {

  method(){
    
  }
}
</script>

<style>

</style>