<template>



<div class="bk">
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav">
        <a class="nav-link active" aria-current="page" href="/login">About us</a>
        <a class="nav-link" href="/enroll">구독</a>
        
      </div>
    </div>
  </div>
</nav>
</div>
  
</template>

<script>
export default {

}
</script>

<style>
.login{
  margin-top: 10px;
  margin-left: 90%;
  text-decoration-line: none;

}
.bk{
  margin-top: 20px;
}

</style>