<template>

 
  <h1>여기는 로그인페이지</h1>
  
    <div class="col" style="margin-left:35%; margin-right:35%; margin-top:20%;">
     <div class="p-3 border bg-light">
      <br>
        <div class="mb-3 row">
          <label for="staticEmail" class="col-sm-2 col-form-label">ID</label>
          <div class="col-sm-10">
            <input type="text" class="form-control" id="staticEmail">
          </div>
        </div>
        <br>
  <div class="mb-3 row">
    <label for="inputPassword" class="col-sm-2 col-form-label">Password</label>
    <div class="col-sm-10" >
      <input type="password" class="form-control" id="inputPassword">
    </div>
    <br><br><br>
    <div style="text-align:center">
     <button type="submit" class="btn btn-primary" style="width:80px;">로그인</button>
     </div>
  </div>



     </div>

    </div>
    
  
<br><br><br><br><br><br><br><br><br><br>





</template>

<script>
export default {

}
</script>

<style>
.col{
  margin: 5%;
 


}


</style>